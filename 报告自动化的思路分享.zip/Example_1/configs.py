# -*- coding: utf-8 -*-

filepath = './Example_1/'
date = u'20180528'
bd = u'PS'
author = u'作者君'


